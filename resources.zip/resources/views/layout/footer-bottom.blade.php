  
        </div>
        <!-- END wrapper -->
  
  <!-- Vendor js -->
  <script src="{{ url('/') }}/adminpanel/js/vendor.min.js"></script>



  <!-- App js -->
  <script src="{{ url('/') }}/adminpanel/js/app.min.js"></script>
    @stack('js-link')
</body>
</html>