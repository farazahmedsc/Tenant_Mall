<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script> &copy; MadaniMallMN Developed by <a href="https://iconictek.com/">Iconictek</a> 
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-sm-block">
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
</footer>