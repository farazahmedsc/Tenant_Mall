 

<?php $__env->startPush('title'); ?>
  Area
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js-link'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    $('.delete-confirm').on('click', function (event) {
        event.preventDefault();
        const url = $(this).attr('href');
        swal({
            title: 'Are you sure?',
            text: 'This record and it`s details will be permanantly deleted!',
            icon: 'warning',
            buttons: ["Cancel", "Yes!"],
        }).then(function(value) {
            if (value) {
                window.location.href = url;
            }
        });
    });

    $("input[name='search']").keyup(function(e){
        if(e.keyCode == 13)
        {
            // $(this).trigger("enterKey");
            $("#searchForm").submit();
        }
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-section'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        
                    </div>
                    <h4 class="page-title">Area List</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row justify-content-between mb-2">
                            <div class="col-auto">
                                <form action="" id="searchForm" class="search-bar position-relative mb-sm-0 mb-2">
                                    <input type="search" name="search" class="form-control" placeholder="Search..." value="<?php echo e($search); ?>">
                                    <span class="mdi mdi-magnify"></span>
                                </form>                          
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end">
                                    <a href="<?php echo e(route('area_create')); ?>" class="btn btn-primary waves-effect waves-light mb-2 me-2"><i class="mdi mdi-basket me-1"></i> Add Area</a>
                                </div>
                            </div><!-- end col-->
                        </div>

                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap table-borderless table-hover mb-0">
                                <thead class="table-light">
                                    <tr>  
                                        <th>Id</th>                                                      
                                        <th>Shop#</th>
                                        <th>N/A</th>
                                        <th>Type</th>	
                                        <th>Alloted</th>													
                                        <th>Added On</th>
                                        <th>Status</th>
                                        <th style="width: 82px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($area->id); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('area_edit', ['id' => $area->id ])); ?>" class="text-gray-800 text-hover-primary mb-1"><?php echo e($area->name); ?></a></td>
                                            <td><?php echo e($area->dimension); ?></td>
                                            <td>
                                                <?php
                                                $badge = "primary"; 
                                                    
                                                ?>
                                                <div class="badge badge-soft-<?php echo e(($area->type == 'Shop')? "primary" : "warning"); ?>"><?php echo e($area->type); ?></div>
                                            </td>
                                            <td>
                                                <?php if($area->alloted == '1'): ?>
                                                    <div class="badge badge-soft-success">Alloted</div>
                                                <?php else: ?>
                                                <div class="badge badge-soft-danger">Empty</div>
                                                <?php endif; ?>
                                               
                                            </td>

                                            <td><?php echo e(date('F d,Y', strtotime($area->created_at))); ?></td>
                                            <td>
                                                <div class="badge badge-soft-<?php echo e(($area->is_active == 1)? "success" : "danger"); ?>"><?php echo e(($area->is_active == 1)? "Active" : "Inactive"); ?></div>
                                            </td>                                
        
                                            <td>
                                                <a href="<?php echo e(route('area_edit', ['id' => $area->id ])); ?>" class="action-icon"> <i class="mdi mdi-square-edit-outline text-primary"></i></a>
                                                <a href="<?php echo e(route('area_delete', ['id' => $area->id ])); ?>" class="action-icon delete-confirm"> <i class="mdi mdi-delete text-danger"></i></a>
                                            </td>
                                        </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </tbody>
                            </table>
                            <div class="row">
                                <?php echo e($areas->links('vendor.pagination.custom')); ?>

                            </div>
                        </div>

                        
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row -->
        
    </div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/area/area-list.blade.php ENDPATH**/ ?>