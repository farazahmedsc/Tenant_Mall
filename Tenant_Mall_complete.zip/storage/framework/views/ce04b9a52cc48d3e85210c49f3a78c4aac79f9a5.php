
 

<?php $__env->startPush('title'); ?>
  Area
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>
 <!-- Plugins css -->
 <link href="<?php echo e(url('/')); ?>/adminpanel/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo e(url('/')); ?>/adminpanel/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo e(url('/')); ?>/adminpanel/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-link'); ?>
   <!-- plugin js -->
   <script src="<?php echo e(url('/')); ?>/adminpanel/libs/dropzone/min/dropzone.min.js"></script>
   <script src="<?php echo e(url('/')); ?>/adminpanel/libs/select2/js/select2.min.js"></script>
   <script src="<?php echo e(url('/')); ?>/adminpanel/libs/flatpickr/flatpickr.min.js"></script>

   <!-- Init js-->
   <script src="<?php echo e(url('/')); ?>/adminpanel/js/pages/create-project.init.js"></script>

   <script>

        function selectType(e){
            if(e == "Shop"){
                $("#type_detail").removeClass('d-none');
            }else{
                $("#type_detail").addClass('d-none');
                $("#type_detail").val('');
            }
        }
    </script>
<?php $__env->stopPush(); ?>
           
<?php $__env->startSection('main-section'); ?>
    

     <!-- Start Content-->
     <div class="container-fluid">
                        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e($label); ?></h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    
                    <h5 class="form-section mb-3 font-24"><?php echo e($label); ?></h5>
                    <form action="<?php echo e($url); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                                <div class="form-group col-md-6 mb-3">
                                    <label>Name <sup class="text-danger">*</sup></label>
                                    <input type="text" name="name" class="form-control form-control-solid" value="<?php echo e($area->name); ?>" required>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="form-group col-md-6 mb-3">
                                    <label>Dimension</label>
                                    <input type="text" name="dimension" class="form-control form-control-solid" value="<?php echo e($area->dimension); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="form-group col-md-6 mb-3">
                                    <label>Type <sup class="text-danger">*</sup></label>
                                    <select name="type" class="form-control form-select form-select-solid" onchange="selectType(this.value)" required>
                                        <option value="">Select</option>
                                        <option value="Shop" <?php echo e(($area->type == 'Shop')? 'Selected' : ''); ?>>Shop</option>
                                        <option value="Office" <?php echo e(($area->type == 'Office')? 'Selected' : ''); ?>>Office</option>
                                    </select>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="form-group col-md-6 mb-3 <?php echo e(($area->type == 'Shop')? '' : 'd-none'); ?>" id="type_detail">
                                    <label>Type Detail</label>
                                    <select name="type_detail" class="form-control form-select form-select-solid" >
                                        <option value="">Select</option>
                                        <option value="Front Shop" <?php echo e(($area->type_detail == 'Front Shop')? 'Selected' : ''); ?>>Front Shop</option>
                                        <option value="Center Shop" <?php echo e(($area->type_detail == 'Center Shop')? 'Selected' : ''); ?>>Center Shop</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row <?php echo e((!is_null($area->type)) ? '' : 'd-none'); ?>">
                                <div class="form-group col-md-6 mb-3">
                                    <label>Status</label>
                                    <select name="is_active" class="form-control form-select form-select-solid" >                                        
                                        <option value="1" <?php echo e(($area->is_active == 1)? 'Selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e(($area->is_active == 0)? 'Selected' : ''); ?>>Inactive</option>
                                    </select>                                   
                                </div>
                            </div>


                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success waves-effect waves-light m-1"><i class="fe-check-circle me-1"></i> Submit</button>
                                <button type="reset" class="btn btn-light waves-effect waves-light m-1"><i class="fe-x me-1"></i> Cancel</button>
                            </div>
                        </div>
                    </form>

                    </div> <!-- end card-body -->
                </div> <!-- end card-->
            </div> <!-- end col-->
        </div>
        <!-- end row-->
        
    </div> <!-- container -->

<?php $__env->stopSection(); ?>
    




      
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/area/area-add.blade.php ENDPATH**/ ?>