  
        </div>
        <!-- END wrapper -->
  
  <!-- Vendor js -->
  <script src="<?php echo e(url('/')); ?>/adminpanel/js/vendor.min.js"></script>



  <!-- App js -->
  <script src="<?php echo e(url('/')); ?>/adminpanel/js/app.min.js"></script>
    <?php echo $__env->yieldPushContent('js-link'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/layout/footer-bottom.blade.php ENDPATH**/ ?>