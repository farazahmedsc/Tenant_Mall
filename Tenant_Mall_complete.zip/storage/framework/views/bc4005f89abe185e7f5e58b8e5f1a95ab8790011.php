
<?php $__env->startPush('title'); ?>
Add User
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>
<!-- Plugins css -->
<link href="<?php echo e(url('/')); ?>/adminpanel/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(url('/')); ?>/adminpanel/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(url('/')); ?>/adminpanel/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-link'); ?>
<!-- plugin js -->
<script src="<?php echo e(url('/')); ?>/adminpanel/libs/dropzone/min/dropzone.min.js"></script>
<script src="<?php echo e(url('/')); ?>/adminpanel/libs/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('/')); ?>/adminpanel/libs/flatpickr/flatpickr.min.js"></script>

<!-- Init js-->
<script src="<?php echo e(url('/')); ?>/adminpanel/js/pages/create-project.init.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

<!-- Start Content-->
<div class="container-fluid">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($label); ?></h4>
            </div>
        </div>
    </div>     
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                <h5 class="form-section mb-3 font-24"><?php echo e($label); ?></h5>
                <form action="<?php echo e($url); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>First Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="first_name" class="form-control form-control-solid" value="<?php echo e($user->first_name); ?>" required>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Last Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="last_name" class="form-control form-control-solid" value="<?php echo e($user->last_name); ?>"  required>
                            </div>
                        </div>
                        <div class="row">
                        <div class="form-group col-md-6 mb-3">
                                <label>Phone/Mobile <sup class="text-danger">*</sup></label>
                                <input type="text" name="phone_number" class="form-control form-control-solid" value="<?php echo e($user->phone_number); ?>"  required>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>User Name</label>
                                <input type="text" name="username" class="form-control form-control-solid"  value="<?php echo e($user->username); ?>" >
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>Email <sup class="text-danger">*</sup></label>
                                <input type="email" name="email" class="form-control form-control-solid" value="<?php echo e($user->email); ?>" required>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Password <sup class="text-danger">*</sup></label>
                                    <input type="text" name="password" id="drvrPass" class="form-control form-control-solid"  value="<?php echo e($user->password); ?>" aria-describedby="basic-addon2" minlength="6" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>User Type <sup class="text-danger">*</sup></label>
                                <select name="type" class="form-control form-select form-select-solid" onchange="showPaymentFields(this);" required>
                                    <option value="">Select your user type...</option>
                                    <option value="Admin" <?php echo e(($user->type == 'Admin')? 'Selected' : ''); ?>>Admin</option>
                                    <option value="Cash Manager" <?php echo e(($user->type == 'Cash Manager')? 'Selected' : ''); ?>>Cash Manager</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label class="form-label">Photo of User</label>
                                <input type="file" name="photo" class="form-control">                                 
                            </div>
                            <div class="form-group col-md-6 mb-3 <?php echo e((!is_null($user->is_active)) ? '' : 'd-none'); ?>">
                                <label>Status</label>
                                <select name="is_active" class="form-control form-select form-select-solid" >                                        
                                    <option value="1" <?php echo e(($user->is_active == 1)? 'Selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(($user->is_active == 0)? 'Selected' : ''); ?>>Inactive</option>
                                </select>                                   
                            </div>
                        </div>


                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-success waves-effect waves-light m-1"><i class="fe-check-circle me-1"></i> Submit</button>
                            <button type="reset" class="btn btn-light waves-effect waves-light m-1"><i class="fe-x me-1"></i> Cancel</button>
                        </div>
                    </div>
                </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col-->
    </div>
    <!-- end row-->
    
</div> <!-- container -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/user/user-add.blade.php ENDPATH**/ ?>