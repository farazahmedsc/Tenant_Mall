 

<?php $__env->startPush('title'); ?>
  Setting
<?php $__env->stopPush(); ?>


<?php $__env->startPush('css-link'); ?>
    <!-- Plugins css -->
    <link href="assets/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
    
<?php $__env->stopPush(); ?>


  
<?php $__env->startSection('main-section'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            
                        </ol>
                    </div>
                    <h4 class="page-title">Settings</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    <form action="<?php echo e(url('/setting_update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <h5 class="form-section mb-3 font-24">Info</h5>
                        <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label>Company Name <sup class="text-danger">*</sup></label>
                            <input type="text" name="name" value="<?php echo e($company->name); ?>" class="form-control form-control-solid" placeholder="Company Name..." required>
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label>Street <sup class="text-danger">*</sup></label>
                            
                            <input type="text" name="street" value="<?php echo e($company->street); ?>" class="form-control form-control-solid" placeholder="Street..." required>
                        </div>
                        </div>
                        <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label>Apt/Suite/Other <sup class="text-danger">*</sup></label>
                            <input type="text" name="apt" value="<?php echo e($company->apt); ?>" class="form-control form-control-solid" placeholder="Apt/Suite/Other..." required>
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label>Zip <sup class="text-danger">*</sup></label>
                            <input type="text" name="zip" value="<?php echo e($company->zip); ?>" class="form-control form-control-solid" placeholder="Zip..." required>
                        </div>
                        </div>
                        <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label>State <sup class="text-danger">*</sup></label>
                            <select name="state" class="form-control form-select form-select-solid" onChange="fetchCitiesByState(this, 'city_id', 'https://fleetly.app')" required>
                                <option value="">Select State</option>
                                <option value="Alabama" <?php echo e(($company->state == 'Alabama')? 'Selected' : ''); ?>>Alabama</option>
                                <option value="Alaska" <?php echo e(($company->state == 'Alaska')? 'Selected' : ''); ?>>Alaska</option>
                                    <option value="Arizona" <?php echo e(($company->state == 'Arizona')? 'Selected' : ''); ?>>Arizona</option>
                                    <option value="Arkansas" <?php echo e(($company->state == 'Arkansas')? 'Selected' : ''); ?>>Arkansas</option>
                                    <option value="Byram" <?php echo e(($company->state == 'Byram')? 'Selected' : ''); ?>>Byram</option>
                                    <option value="California" <?php echo e(($company->state == 'California')? 'Selected' : ''); ?>>California</option>
                                    <option value="Cokato" <?php echo e(($company->state == 'Cokato')? 'Selected' : ''); ?>>Cokato</option>
                                    <option value="Colorado" <?php echo e(($company->state == 'Colorado')? 'Selected' : ''); ?>>Colorado</option>
                                    <option value="Connecticut" <?php echo e(($company->state == 'Connecticut')? 'Selected' : ''); ?>>Connecticut</option>
                                    <option value="Delaware" <?php echo e(($company->state == 'Delaware')? 'Selected' : ''); ?>>Delaware</option>
                                    <option value="Dist. of Columbia" <?php echo e(($company->state == 'Dist. of Columbia')? 'Selected' : ''); ?>>Dist. of Columbia</option>
                                    <option value="Florida" <?php echo e(($company->state == 'Florida')? 'Selected' : ''); ?>>Florida</option>
                                    <option value="Georgia" <?php echo e(($company->state == 'Georgia')? 'Selected' : ''); ?>>Georgia</option>
                                    <option value="Hawaii" <?php echo e(($company->state == 'Hawaii')? 'Selected' : ''); ?>>Hawaii</option>
                                    <option value="Idaho" <?php echo e(($company->state == 'Idaho')? 'Selected' : ''); ?>>Idaho</option>
                                    <option value="Illinois" <?php echo e(($company->state == 'Illinois')? 'Selected' : ''); ?>>Illinois</option>
                                    <option value="Indiana" <?php echo e(($company->state == 'Indiana')? 'Selected' : ''); ?>>Indiana</option>
                                    <option value="Iowa" <?php echo e(($company->state == 'Iowa')? 'Selected' : ''); ?>>Iowa</option>
                                    <option value="Kansas" <?php echo e(($company->state == 'Kansas')? 'Selected' : ''); ?>>Kansas</option>
                                    <option value="Kentucky" <?php echo e(($company->state == 'Kentucky')? 'Selected' : ''); ?>>Kentucky</option>
                                    <option value="Louisiana" <?php echo e(($company->state == 'Louisiana')? 'Selected' : ''); ?>>Louisiana</option>
                                    <option value="Lowa" <?php echo e(($company->state == 'Lowa')? 'Selected' : ''); ?>>Lowa</option>
                                    <option value="Maine" <?php echo e(($company->state == 'Maine')? 'Selected' : ''); ?>>Maine</option>
                                    <option value="Maryland" <?php echo e(($company->state == 'Maryland')? 'Selected' : ''); ?>>Maryland</option>
                                    <option value="Massachusetts" <?php echo e(($company->state == 'Massachusetts')? 'Selected' : ''); ?>>Massachusetts</option>
                                    <option value="Medfield" <?php echo e(($company->state == 'Medfield')? 'Selected' : ''); ?>>Medfield</option>
                                    <option value="Michigan" <?php echo e(($company->state == 'Michigan')? 'Selected' : ''); ?>>Michigan</option>
                                    <option value="Minnesota" <?php echo e(($company->state == 'Minnesota')? 'Selected' : ''); ?>>Minnesota</option>
                                    <option value="Mississippi" <?php echo e(($company->state == 'Mississippi')? 'Selected' : ''); ?>>Mississippi</option>
                                    <option value="Missouri" <?php echo e(($company->state == 'Missouri')? 'Selected' : ''); ?>>Missouri</option>
                                    <option value="Montana" <?php echo e(($company->state == 'Montana')? 'Selected' : ''); ?>>Montana</option>
                                    <option value="Nebraska" <?php echo e(($company->state == 'Nebraska')? 'Selected' : ''); ?>>Nebraska</option>
                                    <option value="Nevada" <?php echo e(($company->state == 'Nevada')? 'Selected' : ''); ?>>Nevada</option>
                                    <option value="New Hampshire" <?php echo e(($company->state == 'New Hampshire')? 'Selected' : ''); ?>>New Hampshire</option>
                                    <option value="New Jersey" <?php echo e(($company->state == 'New Jersey')? 'Selected' : ''); ?>>New Jersey</option>
                                    <option value="New Mexico" <?php echo e(($company->state == 'New Mexico')? 'Selected' : ''); ?>>New Mexico</option>
                                    <option value="New York" <?php echo e(($company->state == 'New York')? 'Selected' : ''); ?>>New York</option>
                                    <option value="North Carolina" <?php echo e(($company->state == 'North Carolina')? 'Selected' : ''); ?>>North Carolina</option>
                                    <option value="North Dakota" <?php echo e(($company->state == 'North Dakota')? 'Selected' : ''); ?>>North Dakota</option>
                                    <option value="Ohio" <?php echo e(($company->state == 'Ohio')? 'Selected' : ''); ?>>Ohio</option>
                                    <option value="Oklahoma" <?php echo e(($company->state == 'Oklahoma')? 'Selected' : ''); ?>>Oklahoma</option>
                                    <option value="Ontario" <?php echo e(($company->state == 'Ontario')? 'Selected' : ''); ?>>Ontario</option>
                                    <option value="Oregon" <?php echo e(($company->state == 'Oregon')? 'Selected' : ''); ?>>Oregon</option>
                                    <option value="Pennsylvania" <?php echo e(($company->state == 'Pennsylvania')? 'Selected' : ''); ?>>Pennsylvania</option>
                                    <option value="Ramey" <?php echo e(($company->state == 'Ramey')? 'Selected' : ''); ?>>Ramey</option>
                                    <option value="Rhode Island" <?php echo e(($company->state == 'Rhode Island')? 'Selected' : ''); ?>>Rhode Island</option>
                                    <option value="South Carolina" <?php echo e(($company->state == 'South Carolina')? 'Selected' : ''); ?>>South Carolina</option>
                                    <option value="South Dakota" <?php echo e(($company->state == 'South Dakota')? 'Selected' : ''); ?>>South Dakota</option>
                                    <option value="Sublimity" <?php echo e(($company->state == 'Sublimity')? 'Selected' : ''); ?>>Sublimity</option>
                                    <option value="Tennessee" <?php echo e(($company->state == 'Tennessee')? 'Selected' : ''); ?>>Tennessee</option>
                                    <option value="Texas" <?php echo e(($company->state == 'Texas')? 'Selected' : ''); ?>>Texas</option>
                                    <option value="Trimble" <?php echo e(($company->state == 'Trimble')? 'Selected' : ''); ?>>Trimble</option>
                                    <option value="Utah" <?php echo e(($company->state == 'Utah')? 'Selected' : ''); ?>>Utah</option>
                                    <option value="Vermont" <?php echo e(($company->state == 'Vermont')? 'Selected' : ''); ?>>Vermont</option>
                                    <option value="Virginia" <?php echo e(($company->state == 'Virginia')? 'Selected' : ''); ?>>Virginia</option>
                                    <option value="Washington" <?php echo e(($company->state == 'Washington')? 'Selected' : ''); ?>>Washington</option>
                                    <option value="West Virginia" <?php echo e(($company->state == 'West Virginia')? 'Selected' : ''); ?>>West Virginia</option>
                                    <option value="Wisconsin" <?php echo e(($company->state == 'Wisconsin')? 'Selected' : ''); ?>>Wisconsin</option>
                                    <option value="Wyoming" <?php echo e(($company->state == 'Wyoming')? 'Selected' : ''); ?>>Wyoming</option>
                                
                            </select>
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label>City <sup class="text-danger">*</sup></label>
                            <div id="loadingCity"></div>
                            <select name="city" class="form-control form-select form-select-solid" required>
                                <option value="">Select City</option>
                                <option value="Ahuimanu" <?php echo e(($company->city == 'Ahuimanu')? 'Selected' : ''); ?>>Ahuimanu</option>
                                <option value="Aiea" <?php echo e(($company->city == 'Aiea')? 'Selected' : ''); ?>>Aiea</option>
                                    <option value="Aliamanu" <?php echo e(($company->city == 'Aliamanu')? 'Selected' : ''); ?>>Aliamanu</option>
                                    <option value="Ewa Beach" <?php echo e(($company->city == 'Ewa Beach')? 'Selected' : ''); ?>>Ewa Beach</option>
                                    <option value="Haiku" <?php echo e(($company->city == 'Haiku')? 'Selected' : ''); ?>>Haiku</option>
                                    <option value="Halawa" <?php echo e(($company->city == 'Halawa')? 'Selected' : ''); ?>>Halawa</option>
                                    <option value="Hanalei" <?php echo e(($company->city == 'Hanalei')? 'Selected' : ''); ?>>Hanalei</option>
                                    <option value="Hilo" <?php echo e(($company->city == 'Hilo')? 'Selected' : ''); ?>>Hilo</option>
                                    <option value="Holualoa" <?php echo e(($company->city == 'Holualoa')? 'Selected' : ''); ?>>Holualoa</option>
                                    <option value="Minneapolis" <?php echo e(($company->city == 'Minneapolis')? 'Selected' : ''); ?>>Minneapolis</option>
                                    <option value="Kahului" <?php echo e(($company->city == 'Kahului')? 'Selected' : ''); ?>>Kahului</option>
                                    <option value="Kailua" <?php echo e(($company->city == 'Kailua')? 'Selected' : ''); ?>>Kailua</option>
                                    <option value="Kalaheo" <?php echo e(($company->city == 'Kalaheo')? 'Selected' : ''); ?>>Kalaheo</option>
                                    <option value="Kamuela" <?php echo e(($company->city == 'Kamuela')? 'Selected' : ''); ?>>Kamuela</option>
                                    <option value="Kaneohe" <?php echo e(($company->city == 'Kaneohe')? 'Selected' : ''); ?>>Kaneohe</option>
                                    <option value="Kaneohe Station" <?php echo e(($company->city == 'Kaneohe Station')? 'Selected' : ''); ?>>Kaneohe Station</option>
                                    <option value="Kapaa" <?php echo e(($company->city == 'Kapaa')? 'Selected' : ''); ?>>Kapaa</option>
                                    <option value="Kapolei" <?php echo e(($company->city == 'Kapolei')? 'Selected' : ''); ?>>Kapolei</option>
                                    <option value="Kihei" <?php echo e(($company->city == 'Kihei')? 'Selected' : ''); ?>>Kihei</option>
                                    <option value="Kula" <?php echo e(($company->city == 'Kula')? 'Selected' : ''); ?>>Kula</option>
                                    <option value="Lahaina" <?php echo e(($company->city == 'Lahaina')? 'Selected' : ''); ?>>Lahaina</option>
                                    <option value="Lanai City" <?php echo e(($company->city == 'Lanai City')? 'Selected' : ''); ?>>Lanai City</option>
                                    <option value="Lihue" <?php echo e(($company->city == 'Lihue')? 'Selected' : ''); ?>>Lihue</option>
                                    <option value="Makaha" <?php echo e(($company->city == 'Makaha')? 'Selected' : ''); ?>>Makaha</option>
                                    <option value="Makakilo City" <?php echo e(($company->city == 'Makakilo City')? 'Selected' : ''); ?>>Makakilo City</option>
                                    <option value="Makawao" <?php echo e(($company->city == 'Makawao')? 'Selected' : ''); ?>>Makawao</option>
                                    <option value="Mi-Wuk Village" <?php echo e(($company->city == 'Mi-Wuk Village')? 'Selected' : ''); ?>>Mi-Wuk Village</option>
                                    <option value="Mililani Town" <?php echo e(($company->city == 'Mililani Town')? 'Selected' : ''); ?>>Mililani Town</option>
                                    <option value="Naalehu" <?php echo e(($company->city == 'Naalehu')? 'Selected' : ''); ?>>Naalehu</option>
                                    <option value="Nanakuli" <?php echo e(($company->city == 'Nanakuli')? 'Selected' : ''); ?>>Nanakuli</option>
                                    <option value="Pahoa" <?php echo e(($company->city == 'Pahoa')? 'Selected' : ''); ?>>Pahoa</option>
                                    <option value="Pearl City" <?php echo e(($company->city == 'Pearl City')? 'Selected' : ''); ?>>Pearl City</option>
                                    <option value="Schofield Barracks" <?php echo e(($company->city == 'Schofield Barracks')? 'Selected' : ''); ?>>Schofield Barracks</option>
                                    <option value="Wahiawa" <?php echo e(($company->city == 'Wahiawa')? 'Selected' : ''); ?>>Wahiawa</option>
                                    <option value="Waialua" <?php echo e(($company->city == 'Waialua')? 'Selected' : ''); ?>>Waialua</option>
                                    <option value="Waianae" <?php echo e(($company->city == 'Waianae')? 'Selected' : ''); ?>>Waianae</option>
                                    <option value="Wailuku" <?php echo e(($company->city == 'Wailuku')? 'Selected' : ''); ?>>Wailuku</option>
                                    <option value="Waimalu" <?php echo e(($company->city == 'Waimalu')? 'Selected' : ''); ?>>Waimalu</option>
                                    <option value="Waipahu" <?php echo e(($company->city == 'Waipahu')? 'Selected' : ''); ?>>Waipahu</option>
                                    <option value="Waipio" <?php echo e(($company->city == 'Waipio')? 'Selected' : ''); ?>>Waipio</option>
                            </select>
                        </div>
                        </div>
                        <div class="row">
                        <div class="form-group col-md-6 mb-3">
                            <label>Phone/Mobile <sup class="text-danger">*</sup></label>
                            <input type="text" name="phone_number" value="<?php echo e($company->phone_number); ?>" class="form-control form-control-solid" placeholder="Phone/Mobile..." required>
                        </div>
                        <div class="form-group col-md-6 mb-3">
                            <label>Email <sup class="text-danger">*</sup></label>
                            <input type="email" name="email" value="<?php echo e($company->email); ?>" class="form-control form-control-solid" placeholder="Email..." required>
                        </div>
                        </div>
                        
                        <div class="row">
                        <div class="form-group col-md-12 mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control form-control-solid" placeholder="Description of your company..." rows="5"><?php echo e($company->description); ?></textarea>
                        </div>
                        </div>


                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success waves-effect waves-light m-1"><i class="fe-check-circle me-1"></i> Submit</button>
                                <button type="reset" class="btn btn-light waves-effect waves-light m-1"><i class="fe-x me-1"></i> Cancel</button>
                            </div>
                        </div>
                    </form>
                    </div> <!-- end card-body -->
                </div> <!-- end card-->
            </div> <!-- end col-->
        </div>
        <!-- end row-->
        
    </div> <!-- container -->


<?php $__env->stopSection(); ?>
               
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/settings.blade.php ENDPATH**/ ?>