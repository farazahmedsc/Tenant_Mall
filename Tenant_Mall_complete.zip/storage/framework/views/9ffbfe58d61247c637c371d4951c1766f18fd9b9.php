
<?php $__env->startPush('title'); ?>
<?php echo e($label); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>
<!-- Plugins css -->
<link href="assets/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
<link href="assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-link'); ?>
<!-- plugin js -->
<script src="assets/libs/dropzone/min/dropzone.min.js"></script>
<script src="assets/libs/select2/js/select2.min.js"></script>
<script src="assets/libs/flatpickr/flatpickr.min.js"></script>

<!-- Init js-->
<script src="assets/js/pages/create-project.init.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>


<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">

                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($label); ?></h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h5 class="form-section mb-3 font-24"><?php echo e($label); ?></h5>
                    <form action="<?php echo e($url); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>First Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="first_name" class="form-control form-control-solid" value="<?php echo e($tenant->first_name); ?>" required>
                                <span class="text-danger">
                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Last Name</label>
                                <input type="text" name="last_name" class="form-control form-control-solid" value="<?php echo e($tenant->last_name); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>Phone/Mobile </label>
                                <input type="text" name="phone_number" class="form-control form-control-solid" value="<?php echo e($tenant->phone_number); ?>" >
                                <span class="text-danger">
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Business Name</label>
                                <input type="text" name="business_name" class="form-control form-control-solid" value="<?php echo e($tenant->business_name); ?>">
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control form-control-solid" value="<?php echo e($tenant->email); ?>">
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Area Alloted<sup class="text-danger">*</sup></label>
                                <select name="area_alloted" class="form-control form-select form-select-solid" required >
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                           
                                      
                                        <option value="<?php echo e($area->id); ?>" <?php echo e(($tenant->area_alloted == $area->id && str_contains($label, 'Update'))? "Selected" : "" ); ?>><?php echo e($area->name); ?></option>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </select>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Acquiring Date</label>
                                <input type="date" name="acquiring_date" value="<?php echo e($tenant->acquiring_date); ?>" class="form-control form-control-solid">
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Monthly Rent Amount <sup class="text-danger">*</sup></label>
                                <input type="number" name="rent" value="<?php echo e($tenant->rent); ?>" class="form-control form-control-solid">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['rent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label>Maintenance Amount </label>
                                <input type="number" name="maintenance" value="<?php echo e($tenant->maintenance); ?>" class="form-control form-control-solid">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['maintenance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                        </div>


                        

                        <div class="row">
                            <div class="form-group col-md-6 mb-3 d-none" >
                                <label>Photo of Tenant</label>
                                <input type="file" name="photo" class="form-control">                                 
                            </div>

                            <div class="form-group col-md-6 mb-3 <?php echo e((!is_null($tenant->is_active)) ? '' : 'd-none'); ?>">
                                <label>Status</label>
                                <select name="is_active" class="form-control form-select form-select-solid" >                                        
                                    <option value="1" <?php echo e(($tenant->is_active == 1)? 'Selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(($tenant->is_active == 0)? 'Selected' : ''); ?>>Inactive</option>
                                </select>                                   
                            </div>

                       
                        </div>
                            <hr>
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label>Upload Driver License/ID Card</label>
                                <input type="file" name="license" class="form-control">                                 
                            </div>

                            <div class="form-group col-md-6 mb-3">
                                <label>Upload business Registration Document</label>
                                <input type="file" name="registration" class="form-control">                                 
                            </div>

                            <div class="form-group col-md-6 mb-3">
                                <label>Upload Insurance</label>
                                <input type="file" name="insurance" class="form-control">                                 
                            </div>

                            <div class="form-group col-md-6 mb-3">
                                <label>Upload The Lease</label>
                                <input type="file" name="lease" class="form-control">                                 
                            </div>

                        </div>

                        <?php if($label == "Update Tenant" ): ?>

                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <b>Driver License/ID Card: </b> <a href="<?php echo e(url('/')); ?>/uploads/tenant/<?php echo e($tenant->license); ?>" target="_blank"><?php echo e(str_replace($tenant->first_name."_", "",$tenant->license)); ?></a> <br>
                                    <b>business Registration Document: </b> <a href="<?php echo e(url('/')); ?>/uploads/tenant/<?php echo e($tenant->registration); ?>" target="_blank"><?php echo e(str_replace($tenant->first_name."_", "",$tenant->registration)); ?></a> <br>
                                    <b>Insurance: </b> <a href="<?php echo e(url('/')); ?>/uploads/tenant/<?php echo e($tenant->insurance); ?>" target="_blank"><?php echo e(str_replace($tenant->first_name."_", "",$tenant->insurance)); ?></a> <br>
                                    <b>The Lease: </b> <a href="<?php echo e(url('/')); ?>/uploads/tenant/<?php echo e($tenant->lease); ?>" target="_blank"><?php echo e(str_replace($tenant->first_name."_", "",$tenant->lease)); ?></a> <br>

                                
                                
                                
                                </div>
                            </div>    

                            
                        <?php endif; ?>


                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success waves-effect waves-light m-1"><i
                                        class="fe-check-circle me-1"></i> Submit</button>
                                <button type="reset" class="btn btn-light waves-effect waves-light m-1"><i
                                        class="fe-x me-1"></i> Cancel</button>
                            </div>
                        </div>
                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col-->
    </div>
    <!-- end row-->

</div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/tenant/tenant-add.blade.php ENDPATH**/ ?>