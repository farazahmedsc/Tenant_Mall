

<?php $__env->startPush('title'); ?>
Users
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js-link'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    $('.delete-confirm').on('click', function (event) {
        event.preventDefault();
        const url = $(this).attr('href');
        swal({
            title: 'Are you sure?',
            text: 'This record and it`s details will be permanantly deleted!',
            icon: 'warning',
            buttons: ["Cancel", "Yes!"],
        }).then(function(value) {
            if (value) {
                window.location.href = url;
            }
        });
    });

    $("input[name='search']").keyup(function(e){
        if(e.keyCode == 13)
        {
            // $(this).trigger("enterKey");
            $("#searchForm").submit();
        }
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-section'); ?>


<!-- Start Content-->
<div class="container-fluid">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        
                    </ol>
                </div>
                <h4 class="page-title">Users List</h4>
            </div>
        </div>
    </div>     
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-between mb-2">
                        <div class="col-auto">
                            <form class="search-bar position-relative mb-sm-0 mb-2">
                                <input type="text" name="search" class="form-control" placeholder="Search...">
                                <span class="mdi mdi-magnify"></span>
                            </form>                               
                        </div>
                        <div class="col-md-6">
                            <div class="text-md-end">
                                <a href="<?php echo e(route('user_create')); ?>" class="btn btn-primary waves-effect waves-light mb-2 me-2"><i class="mdi mdi-basket me-1"></i> Add User</a>
                            </div>
                        </div><!-- end col-->
                    </div>

                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-borderless table-hover mb-0">
                            <thead class="table-light">
                                <tr>      
                                    <th>Photo</th>                             
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>User Name</th>
                                    <th>User Type</th>
                                    <th>Added On</th>
                                    <th>Status</th>
                                    <th style="width: 82px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><img src="<?php echo e(url('/')); ?>/uploads/user/<?php echo e((is_null($user->photo))? 'avatar.jpg' : $user->photo); ?>" alt="User Photo" class="img-table"></td>
                                        <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone_number); ?></td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td><?php echo e($user->type); ?></td>
                                        <td><?php echo e(date('F d,Y', strtotime($user->created_at))); ?></td>    
                                        <td>
                                            <div class="badge badge-soft-<?php echo e(($user->is_active == 1)? "success" : "danger"); ?>"><?php echo e(($user->is_active == 1)? "Active" : "Inactive"); ?></div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('user_edit', ['id' => $user->id ])); ?>" class="action-icon"> <i class="mdi mdi-square-edit-outline text-primary"></i></a>
                                            <a href="<?php echo e(route('user_delete', ['id' => $user->id ])); ?>" class="action-icon delete-confirm"> <i class="mdi mdi-delete text-danger"></i></a>
                                        </td> 
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                
                                
                                
                            </tbody>
                        </table>
                        <div class="row">
                            <?php echo e($users->links('vendor.pagination.custom')); ?>

                        </div>
                    </div>

                    <ul class="pagination pagination-rounded justify-content-end my-2">
                        <li class="page-item">
                            <a class="page-link" href="javascript: void(0);" aria-label="Previous">
                                <span aria-hidden="true">«</span>
                                <span class="visually-hidden">Previous</span>
                            </a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="javascript: void(0);">1</a></li>
                        <li class="page-item"><a class="page-link" href="javascript: void(0);">2</a></li>
                        <li class="page-item"><a class="page-link" href="javascript: void(0);">3</a></li>
                        <li class="page-item"><a class="page-link" href="javascript: void(0);">4</a></li>
                        <li class="page-item"><a class="page-link" href="javascript: void(0);">5</a></li>
                        <li class="page-item">
                            <a class="page-link" href="javascript: void(0);" aria-label="Next">
                                <span aria-hidden="true">»</span>
                                <span class="visually-hidden">Next</span>
                            </a>
                        </li>
                    </ul>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row -->
    
</div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tenant_Mall\resources\views/adminpanel/user/user-list.blade.php ENDPATH**/ ?>